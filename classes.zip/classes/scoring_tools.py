import numpy as np
import pandas as pd
import copy
from typing import List, Tuple, Dict, Any

from optbinning import OptimalBinning, ContinuousOptimalBinning

from sklearn.utils.validation import check_array, check_is_fitted
from sklearn.base import BaseEstimator, TransformerMixin
from scipy.ndimage import shift
from scipy import stats
from sklearn.model_selection import train_test_split

from sklearn.pipeline import Pipeline, make_pipeline
# from sklearn.preprocessing import OrdinalEncoder
from sklearn.compose import ColumnTransformer

from sklearn.metrics import precision_recall_curve 
from sklearn.metrics import auc
from sklearn.metrics import r2_score
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score
from sklearn.base import clone
import pygad

from termcolor import colored
from functools import reduce

import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve

custom_plot_style = {
'axes.titlesize' :      'medium',
'axes.labelsize' :      7,
'axes.grid':            True,
'axes.grid.axis':       'y',
'axes.grid.which':      'major',
'axes.edgecolor':       '282828',
'axes.linewidth':       1.0,
'axes.spines.left':     False,
'axes.spines.bottom':   True,
'axes.spines.top':      False,
'axes.spines.right':    False,
'axes.labelweight':     'bold',
'axes.labelcolor':      '282828',
'grid.color':           'b0b0b0',
'grid.linestyle':       '-',     
'grid.linewidth':       0.5,    
'grid.alpha':           0.5,    
'lines.linewidth' :     0.75,
'lines.markersize' :    10,
'hatch.linewidth':      0.25,
'patch.antialiased':    True,
'xtick.top':            False,
'xtick.bottom':         True,
'xtick.major.size':     3.0,
'xtick.minor.size':     2.0,
'xtick.major.width':    1.0,
'xtick.minor.width':    0.5,
'xtick.direction':      'in',
'xtick.minor.visible':  False,
'xtick.major.top':      False,
'xtick.major.bottom':   True,
'xtick.minor.top':      False,
'xtick.minor.bottom':   False,
'xtick.major.pad':      4.0,
'xtick.minor.pad':      4.0,
'ytick.labelsize':      6,
'xtick.color':          'black',
'ytick.color':          'black',
'ytick.left':           False,
'ytick.right':          False,
'ytick.major.size':     3.0,
'ytick.minor.size':     2.0,
'ytick.major.width':    0.5,
'ytick.minor.width':    0.5,
'ytick.direction':      'in',
'ytick.minor.visible':  False,
'ytick.major.left':     True,
'ytick.major.right':    True,
'ytick.minor.left':     True,
'ytick.minor.right':    True,
'ytick.major.pad':      4.0,
'ytick.minor.pad':      4.0,
'xtick.labelsize':      6,
'legend.frameon':       False,
'legend.fontsize':      5,
'figure.figsize':       [5.0, 3.0],
'figure.subplot.left':  0.125,
'figure.subplot.bottom':0.175,
'figure.subplot.top':   0.95,
'figure.subplot.right': 0.95,
'figure.autolayout':    False,
'path.simplify' :       True}

def model_scores(data: pd.DataFrame,
                y_pred: str,
                y_true: str,
                names: str = None ) -> pd.DataFrame:
    
    results = []

    if names is None:
        data_chunk = data[[y_pred, y_true]].copy()
        data_chunk['names'] = 'model'
        names = 'names'
    else:
        data_chunk = data[[y_pred, y_true, names]].copy()

    for model in data_chunk[names].unique():
        model_data = data_chunk[data_chunk[names] == model].copy()

        results.append(
            {'model': model,
            'accuracy': np.round(accuracy_score(model_data[y_true], model_data[y_pred]), 3),
            'precision': np.round(precision_score(model_data[y_true], model_data[y_pred]), 3),
            'recall': np.round(recall_score(model_data[y_true], model_data[y_pred]), 3),
            'f1': np.round(f1_score(model_data[y_true], model_data[y_pred]), 3),})
            
    return pd.DataFrame(results)
    


def model_roc(data: pd.DataFrame,
              y_proba: str,
              y_true: str,
              names: str = None,
              figsize=(3,2)):
    
    with plt.style.context(custom_plot_style):
        fig, ax = plt.subplots(figsize=figsize, dpi=200)
        
        if names is None:
            data_chunk = data[[y_proba, y_true]].copy()
            data_chunk['names'] = 'model'
            names = 'names'
        else:
            data_chunk = data[[y_proba, y_true, names]].copy()

        for model in data_chunk[names].unique():
            model_data = data_chunk[data_chunk[names] == model].copy()

            auc = np.round(roc_auc_score(model_data[y_true], model_data[y_proba]), 4)
            fpr, tpr, _ = roc_curve(model_data[y_true], model_data[y_proba])
            plt.plot(fpr, tpr, label=f"{model}, AUC={auc}")

    ax.spines['top'].set_visible(True)
    ax.spines['right'].set_visible(True)
    ax.spines['left'].set_visible(True)

    plt.axline((0, 0), (1, 1), linewidth=1, color='r')
    plt.margins(x=0.05, y=0.05)
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")

    plt.title("Receiver Operating Characteristic (ROC) Curve", fontsize=8)
    plt.legend(fontsize=5)

    return fig


def model_lift(data: pd.DataFrame,
              y_proba: str,
              y_true: str,
              names: str = None,
              step = 0.1,
              figsize=(6,2.5)):
    
    with plt.style.context(custom_plot_style):
        fig, ax = plt.subplots(ncols=2, nrows=1, figsize=figsize, dpi=200)
        ax = ax.flatten()
        if names is None:
            data_chunk = data[[y_proba, y_true]].copy()
            data_chunk['names'] = 'model'
            names = 'names'
        else:
            data_chunk = data[[y_proba, y_true, names]].copy()

        for model in data_chunk[names].unique():
            model_data = data_chunk[data_chunk[names] == model].copy()
            model_data.sort_values(y_proba, ascending=False, inplace=True)
            model_data = model_data.reset_index(drop=True)

            base_rate = model_data[y_true].mean()

            model_data['bin'] = np.floor((model_data.index / len(model_data) / step).astype(int))
            lift = (model_data.groupby('bin')
                    .agg(event = (y_true, 'sum'),
                         count = (y_true, 'count'),
                         proba = (y_proba, 'min'))
                    .reset_index())
            
            lift['cum_event'] = lift['event'].cumsum()
            lift['cum_count'] = lift['count'].cumsum()
            lift['event_rate'] = lift['cum_event'] / lift['cum_count']
            lift['lift'] = lift['event_rate'] / base_rate
            lift['sample_size'] = lift['bin'] * step + step

            ax[0].plot(lift['sample_size'], lift['lift'], label=f"{model}")
            ax[1].plot(lift['proba'], lift['lift'], label=f"{model}")

    ax[0].spines['top'].set_visible(True)
    ax[0].spines['right'].set_visible(True)
    ax[0].spines['left'].set_visible(True)
    ax[0].set_xlim([step,1])
    ax[0].set_title("Lift Curve", fontsize=8)
    ax[0].set_xlabel("Proportion of sample")
    ax[0].set_ylabel("Lift")
    ax[0].margins(x=0.0, y=0.05)
    ax[0].legend(fontsize=5)
    ax[0].set_title("Lift Curve", fontsize=8)

    ax[1].spines['top'].set_visible(True)
    ax[1].spines['right'].set_visible(True)
    ax[1].spines['left'].set_visible(True)
    ax[1].set_xlim([0,1])
    ax[1].set_title("Lift Curve", fontsize=8)
    ax[1].set_xlabel("Threshold")
    ax[1].set_ylabel("Lift")
    ax[1].margins(x=0.0, y=0.05)
    ax[1].legend(fontsize=5)
    ax[1].set_title("Lift Curve", fontsize=8)

    return fig, 


def model_prf(data: pd.DataFrame,
              y_proba: str,
              y_true: str,
              names: str = None,
              figsize=(10,2.5)):
    
    summary = []
    if names is None:
        data_chunk = data[[y_proba, y_true]].copy()
        data_chunk['names'] = 'model'
        names = 'names'
    else:
        data_chunk = data[[y_proba, y_true, names]].copy()

    for model in data_chunk[names].unique():
        model_data = data_chunk[data_chunk[names] == model].copy()
        precision, recall, thresholds = precision_recall_curve(model_data[y_true], 
                                                               model_data[y_proba])
        f1_scores = 2 * recall * precision / (recall + precision)

        summary.append(pd.DataFrame({'model': model,
                        'threshold': thresholds,
                        'precision': precision[:-1],
                        'recall': recall[:-1],
                        'f1': f1_scores[:-1]}))


    summary = pd.concat(summary, axis='index').reset_index(drop=True)
    with plt.style.context(custom_plot_style):
        fig, ax = plt.subplots(1, 3, figsize=figsize, dpi=300)

        sns.lineplot(data=summary, x='threshold', y='precision',
                     hue='model', linewidth=1, errorbar=None, ax=ax[0])
    
        sns.lineplot(data=summary, x='threshold', y='recall',
                     hue='model', linewidth=1, errorbar=None, ax=ax[1])
        
        sns.lineplot(data=summary, x='threshold', y='f1',
                     hue='model', linewidth=1, errorbar=None, ax=ax[2])
        
        for index in range(3):
            ax[index].spines['top'].set_visible(True)
            ax[index].spines['right'].set_visible(True)
            ax[index].spines['left'].set_visible(True)
            ax[index].grid(True)
            ax[index].set_ylim([0,1])

        fig.tight_layout(h_pad=1, w_pad=1)
    
    return fig, ax

def get_gini_table(table: pd.DataFrame, var_names: List[str], target_name: str) -> pd.DataFrame:
    """
    Calculates GINI values with respect to target variable.
    Target variable must be binary. Variables must be discrete, such 
    as after the optimal binnig process.

    Args:
        table (pd.DataFrame): 
            Data table consiting all processed variables and target variable.

        var_names (List[str]): 
            List of variables for which correlationis determined.

        target_name (str):
            Name of the target variable.

    Returns:
        pd.DataFrame: 
            Data frame with GINI values stored in 
            the column 'GINI' and variable names as table indexes.
    """

    if isinstance(table, pd.DataFrame) is False:
        raise TypeError("table expected to be pandas data frame")

    if len(table) == 0:
        raise ValueError("table is empty")

    if isinstance(var_names, list) is False:
        raise TypeError("var_names expected to be List[str]")

    if len(var_names) == 0:
        raise ValueError("var_names list is empty")

    if all([isinstance(x, str) for x in var_names]) is False:
        raise TypeError("var_names list elements expected to be str")

    if isinstance(target_name, str) is False:
        raise TypeError("target_name expected to be str")

    if target_name not in table.columns:
        raise ValueError(f"variable named {var} not found in provided table")

    for var in var_names:
        if var not in table.columns:
            raise ValueError(
                f"variable named {var} not found in provided table")

    index = []
    value = []

    for var in var_names:
        gini_input = (
            table[[var, target_name]]
            .groupby(by=var)
            .agg(shares=(var, 'count'),
                 bad_rate=(target_name, 'mean'))
            .reset_index()
            .sort_values(by='bad_rate', ascending=False))

        gini_input['shares'] = gini_input['shares'] / gini_input['shares'].sum()
        R = np.cumsum(gini_input['shares'].values * gini_input['bad_rate'].values)
        perfect_score = (1-R[-1]/2)-0.5
        R = R/R[-1]
        real_score = np.sum(gini_input['shares'].values * (R+shift(R, 1, cval=0)))/2-0.5
        gini = np.abs((real_score/perfect_score))

        index.append(var)
        value.append(gini)

    return pd.DataFrame(value, index=index, columns=['GINI'])


def get_iv_table(table: pd.DataFrame, var_names: List[str], target_name: str) -> pd.DataFrame:
    """
    Calculates IV values with respect to target variable.
    Target variable must be binary. Variables must be discrete, such 
    as after the optimal binnig process. 

    Args:
        table (pd.DataFrame): 
            Data table consiting all processed variables and target variable.

        var_names (List[str]): 
            List of variables for which correlationis determined.

        target_name (str):
            Name of the target variable.

    Returns:
        pd.DataFrame: 
            Data frame with IV values stored in 
            the column 'IV' and variable names as table indexes.
    """

    if isinstance(table, pd.DataFrame) is False:
        raise TypeError("table expected to be pandas data frame")

    if len(table) == 0:
        raise ValueError("table is empty")

    if isinstance(var_names, list) is False:
        raise TypeError("var_names expected to be List[str]")

    if len(var_names) == 0:
        raise ValueError("var_names list is empty")

    if all([isinstance(x, str) for x in var_names]) is False:
        raise TypeError("var_names list elements expected to be str")

    if isinstance(target_name, str) is False:
        raise TypeError("target_name expected to be str")

    if target_name not in table.columns:
        raise ValueError(f"variable named {var} not found in provided table")

    for var in var_names:
        if var not in table.columns:
            raise ValueError(
                f"variable named {var} not found in provided table")

    index = []
    value = []

    for var in var_names:
        data_input = (
            table[[var, target_name]]
            .groupby(by=var)
            .agg(N=(var, 'count'),
                 event=(target_name, 'sum'))
            .reset_index()
            .sort_values(by='event', ascending=False))

        data_input['non_event'] = data_input['N'] - data_input['event']
        data_input['woe'] = np.log(data_input['non_event'] / data_input['event'])
        data_input['non_event'] = data_input['non_event'] / data_input['non_event'].sum()
        data_input['event'] = data_input['event'] / data_input['event'].sum()

        iv = np.sum((data_input['non_event'] - data_input['event']) * data_input['woe'])
        index.append(var)
        value.append(iv)

    return pd.DataFrame(value, index=index, columns=['IV'])


def get_pbs_table(table: pd.DataFrame, var_names: List[str], target_name: str) -> pd.DataFrame:
    """
    Calculates correlation between continuous variables and
    binary target variable. 

    Args:
        table (pd.DataFrame): 
            Data table consiting all processed variables and target variable.

        var_names (List[str]): 
            List of variables for which correlationis determined.

        target_name (str):
            Name of the target variable.

    Returns:
        pd.DataFrame: 
            Data frame with pointbiserial correlation values stored in 
            the column 'PBS' and variable names as table indexes.
    """

    if isinstance(table, pd.DataFrame) is False:
        raise TypeError("table expected to be pandas data frame")

    if len(table) == 0:
        raise ValueError("table is empty")

    if isinstance(var_names, list) is False:
        raise TypeError("var_names expected to be List[str]")

    if len(var_names) == 0:
        raise ValueError("var_names list is empty")

    if all([isinstance(x, str) for x in var_names]) is False:
        raise TypeError("var_names list elements expected to be str")

    if isinstance(target_name, str) is False:
        raise TypeError("target_name expected to be str")

    if target_name not in table.columns:
        raise ValueError(f"variable named {var} not found in provided table")

    for var in var_names:
        if var not in table.columns:
            raise ValueError(
                f"variable named {var} not found in provided table")

    index = []
    value = []

    for var in var_names:
        cor, val = stats.pointbiserial(table[target_name].values,
                                       table[var].values)
        index.append(var)
        value.append(np.abs(cor))

    return pd.DataFrame(value, index=index, columns=['PBS'])


def get_cor_table(table: pd.DataFrame, var_names: List[str], target_name: str) -> pd.DataFrame:
    """
    Calculates correlation between continuous variables and
    target variable. 

    Args:
        table (pd.DataFrame): 
            Data table consiting all processed variables and target variable.

        var_names (List[str]): 
            List of variables for which correlationis determined.

        target_name (str):
            Name of the target variable.

    Returns:
        pd.DataFrame: 
            Data frame woth correlation values stored in 
            the column 'COR' and variable names as table indexes.
    """

    if isinstance(table, pd.DataFrame) is False:
        raise TypeError("table expected to be pandas data frame")

    if len(table) == 0:
        raise ValueError("table is empty")

    if isinstance(var_names, list) is False:
        raise TypeError("var_names expected to be List[str]")

    if len(var_names) == 0:
        raise ValueError("var_names list is empty")

    if all([isinstance(x, str) for x in var_names]) is False:
        raise TypeError("var_names list elements expected to be str")

    if isinstance(target_name, str) is False:
        raise TypeError("target_name expected to be str")

    if target_name not in table.columns:
        raise ValueError(f"variable named {var} not found in provided table")

    for var in var_names:
        if var not in table.columns:
            raise ValueError(
                f"variable named {var} not found in provided table")

    index = []
    value = []

    for var in var_names:
        # print(table[var].values)
        # print(table[target_name].values)
        # print(np.corrcoef(table[var].astype(float).values, table[target_name].astype(float).values))
        cor = float(
            np.abs((np.corrcoef(table[var].astype(float).values, table[target_name].astype(float).values)[1, 0])))

        index.append(var)
        value.append(np.abs(cor))

    return pd.DataFrame(value, index=index, columns=['COR'])


class BinningFilter(BaseEstimator, TransformerMixin):
    """_summary_

    Args:
        BaseEstimator (_type_): _description_
        TransformerMixin (_type_): _description_
    """

    def __init__(self,
                 target_type: str,
                 variable_type: str,
                 iv_threshold: float = 0,
                #  correlation_threshold: float = 0,
                #  settings: Dict = None,
                 apply_transform: bool = True,
                 allow_nonmonotonic: bool = False):
        """_summary_

        Args:
            target_type (str): _description_
            variable_type (str): _description_
            iv_threshold (float, optional): _description_. Defaults to 0.
            correlation_threshold (float, optional): _description_. Defaults to 0.
            settings (Dict, optional): _description_. Defaults to None.
            apply_transform (bool, optional): _description_. Defaults to True.
            allow_nonmonotonic (bool, optional): _description_. Defaults to False.

        Raises:
            ValueError: _description_
            ValueError: _description_
            ValueError: _description_
        """
        self.settings = {}
        self.target_type = target_type
        if self.target_type == "binary":
            self.metric = "woe"
            # self.settings['min_bin_n_event'] = 30
        elif self.target_type == "continuous":
            self.metric = "mean"
        else:
            raise ValueError(f"target_type expected to be 'binary' or 'continuous' not {self.target_type}")

        if self.target_type == "binary":
            self.metric = "woe"
        elif self.target_type == "continuous":
            self.metric = "mean"
        else:
            raise ValueError(f"target_type expected to be 'binary' or 'continuous' not {self.target_type}")

        self.variable_type = variable_type
        if self.variable_type == 'numerical':
            self.settings['dtype'] = self.variable_type
            self.settings['monotonic_trend'] = 'auto_asc_desc'
            self.settings['min_n_bins'] =  2
            self.settings['max_pvalue'] = 0.1
            if self.target_type == "binary":
                self.settings['solver'] = 'cp'
        elif self.variable_type == 'categorical':
            self.settings['dtype'] = self.variable_type
            self.settings['monotonic_trend'] = 'auto_asc_desc'
            self.settings['cat_cutoff'] =  0.1
            self.settings['min_n_bins'] =  2
            self.settings['max_pvalue'] = 0.1
            if self.target_type == "binary":
                self.settings['solver'] = 'mip'
        else:
            raise ValueError(
                f"target_type expected to be 'numerical' or 'categorical' not {self.target_type}")

        # if settings is not None:
        #     self.settings.update(settings)

        self.iv_threshold = iv_threshold
        # self.correlation_threshold = correlation_threshold
        self.apply_transform = apply_transform
        self.allow_nonmonotonic = allow_nonmonotonic


    def fit(self, X, y):
        """_summary_

        Args:
            X (_type_): _description_
            y (_type_): _description_

        Raises:
            ValueError: _description_

        Returns:
            _type_: _description_
        """
        self.ob_ = {}
        self.iv_ = {}

        y_copy = y.copy().reset_index(drop=True)
        X_copy = X.copy().reset_index(drop=True)

        # X = check_array(X, force_all_finite=False)
        self.n_features_in_ = X_copy.shape[1]

        self.cols_to_drop_ = set()

        for column in X_copy.columns:

            if self.target_type == "binary":
                self.settings['monotonic_trend'] = 'auto_asc_desc'
                optb_1 = OptimalBinning(name=column, **self.settings)
                self.settings['monotonic_trend'] = None
                optb_2 = OptimalBinning(name=column, **self.settings)
            elif self.target_type == "continuous":
                self.settings['monotonic_trend'] = 'auto_asc_desc'
                optb_1 = ContinuousOptimalBinning(name=column, **self.settings)
                self.settings['monotonic_trend'] = None
                optb_2 = ContinuousOptimalBinning(name=column, **self.settings)
            else:
                raise ValueError(f"target_type expected to be 'binary' or 'continuous' not {self.target_type}")

            try:
                optb_1.fit(X_copy.loc[:, column].values, y_copy.values)
            except ValueError as e:
                print(f"An error occured while binning variable {column}")
                self.cols_to_drop_.add(column)
                continue
                # raise

            try:
                optb_2.fit(X_copy.loc[:, column].values, y_copy.values)
            except ValueError as e:
                print(f"An error occured while binning variable {column}")
                self.cols_to_drop_.add(column)
                continue
                # raise
            if self.target_type == "binary":
                c_1 = optb_1.binning_table.build()['IV'].values[-1]
                c_2 = optb_2.binning_table.build()['IV'].values[-1]
            elif self.target_type == "continuous":
                x_1 = optb_1.transform(X_copy.loc[:, column], 
                                       metric=self.metric,
                                       metric_missing='empirical')
                x_2 = optb_2.transform(X_copy.loc[:, column], 
                                       metric=self.metric,
                                       metric_missing='empirical')
                c_1 = np.abs(np.corrcoef(x_1, y_copy)[1,0])
                c_2 = np.abs(np.corrcoef(x_2, y_copy)[1,0])
            else:
                pass

            if self.allow_nonmonotonic:
                if c_1 > c_2:
                    self.ob_[column] = copy.deepcopy(optb_1)
                    self.iv_[column] = c_1       
                else:
                    self.ob_[column] = copy.deepcopy(optb_2)
                    self.iv_[column] = c_2
            else:
                self.ob_[column] = copy.deepcopy(optb_1)
                self.iv_[column] = c_1
                
            if self.iv_[column] < self.iv_threshold:
                self.cols_to_drop_.add(column)

        self.cols_to_keep_ = [x for x in X_copy.columns.to_list() if x not in self.cols_to_drop_]
        self.feature_names_in_ = self.cols_to_keep_

        return self


    def summarise_variable(self, var_name:str) -> pd.DataFrame:
        return self.ob_[var_name].binning_table.build()


    def transform(self, X):
        check_is_fitted(self)
        if self.n_features_in_ != X.shape[1]:
            raise ValueError("Wrong number of features")

        if len(self.cols_to_keep_) == 0:
            raise ValueError("No columns to keep, check threshold values")

        if len(self.cols_to_drop_) == 0:
            X_copy = X.copy()
        else:
            X_copy = X.loc[:, self.cols_to_keep_].copy()

        if self.apply_transform:
            for variable in X_copy.columns:
                X_copy.loc[:, variable] = (self.ob_[variable]
                                           .transform(X_copy.loc[:, variable],
                                                      metric=self.metric,
                                                      metric_missing='empirical'))
                X_copy.loc[:, variable] = X_copy.loc[:, variable].astype(float)
        return X_copy


    def get_feature_names_out(self, input_features=None):
        if input_features is None:
            return getattr(self, "feature_names_in"), [f"x{i}" for i in range(self.n_features_in_)]
        else:
            if len(input_features) != self.n_features_in_:
                raise ValueError(
                    "input features not equal to feature_names_in")

            return self.feature_names_in_


class CorrelationFilter(BaseEstimator, TransformerMixin):

    def __init__(self, 
                 threshold: float = 0.6, 
                 variable_type='binned', 
                 target_type='binary'):

        if isinstance(threshold, float) is False:
            raise TypeError('threshold expected to be float type')

        if threshold < 0.0 or threshold > 1.0:
            raise ValueError('threshold expected to take values from 0 to 1')

        self.threshold = threshold
        self.variable_type = variable_type
        self.target_type = target_type


    def fit(self, X, y):

        X_copy = X.copy()
        if hasattr(X_copy, 'columns'):
            feature_names = X_copy.columns.tolist()

        self.n_features_in_ = X_copy.shape[1]

        X_copy = X_copy.reset_index(drop=True)
        y_copy = y.reset_index(drop=True)

        tab = pd.concat([X_copy, y_copy], axis='columns')
        # print(tab)
        # print(tab.columns)
        # print(feature_names)
        if self.variable_type == 'binned':
            if self.target_type == 'binary':
                gini = get_gini_table(tab, feature_names, tab.columns[-1])
                iv = get_iv_table(tab, feature_names, tab.columns[-1])
            if self.target_type == 'continuous':
                cor_target = get_cor_table(tab, feature_names, tab.columns[-1])
        elif self.variable_type == 'continuous':

            if self.target_type == 'binary':
                pbs = get_pbs_table(tab, feature_names, tab.columns[-1])

            if self.target_type == 'continuous':
                cor_target = get_cor_table(tab, feature_names, tab.columns[-1])
        else:
            raise ValueError()

        self.cols_to_drop_ = set()
        for index_1, variable in enumerate(X_copy.columns[:-1]):

            if variable in self.cols_to_drop_:
                continue

            cor = X_copy.corrwith(X_copy[variable])
            for index_2 in range(index_1+1, len(X_copy.columns)):

                if X_copy.columns[index_2] in self.cols_to_drop_:
                    continue

                if np.abs(cor.iloc[index_2]) > self.threshold:
                    if self.variable_type == 'binned':
                        if self.target_type == 'binary':
                            score_1 = ((gini['GINI'][index_1]) * iv['IV'][index_1])**(1/2)
                            score_2 = ((gini['GINI'][index_2]) * iv['IV'][index_2])**(1/2)
                        elif self.target_type == 'continuous':
                            score_1 = cor_target['COR'][index_1]
                            score_2 = cor_target['COR'][index_2]
                    elif self.variable_type == 'continuous':
                        if self.target_type == 'binary':
                            score_1 = pbs['PBS'][index_1]
                            score_2 = pbs['PBS'][index_2]
                        elif self.target_type == 'continuous':
                            score_1 = cor_target['COR'][index_1]
                            score_2 = cor_target['COR'][index_2]
                        else:
                            ValueError()
                    else:
                        ValueError()

                    if score_2 >= score_1:
                        self.cols_to_drop_.add(X_copy.columns[index_1])
                        break

                    if score_2 < score_1:
                        self.cols_to_drop_.add(X_copy.columns[index_2])
                        break

        self.cols_to_drop_ = list(self.cols_to_drop_)
        self.cols_to_keep_ = [x for x in X_copy.columns.to_list() if x not in self.cols_to_drop_]
        self.feature_names_in_ = self.cols_to_keep_

        return self

    def transform(self, X):
        check_is_fitted(self)
        if self.n_features_in_ != X.shape[1]:
            raise ValueError("Wrong number of features")

        if len(self.cols_to_keep_) == 0:
            raise ValueError("No columns to keep, check threshold values")

        X_copy = X.copy()
        if len(self.cols_to_drop_) == 0:
            return X_copy
        else:
            return X_copy.loc[:, self.cols_to_keep_].copy()


    def get_feature_names_out(self, input_features=None):
        if input_features is None:
            return getattr(self, "feature_names_in"), [f"x{i}" for i in range(self.n_features_in_)]
        else:
            if len(input_features) != self.n_features_in_:
                raise ValueError("input features not equal to feature_names_in")

            return self.feature_names_in_


class BaseFilter(BaseEstimator, TransformerMixin):

    def __init__(self,
                 null_frq: float = 0.95,
                 max_shares: float = 0.95,
                 nunique: int = 2):

        if isinstance(null_frq, (int, float)) is False:
            raise TypeError("null_frq expected to be float or int type")

        if isinstance(max_shares, (int, float)) is False:
            raise TypeError("max_shares expected to be float or int type")

        if isinstance(nunique, (int, float)) is False:
            raise TypeError("nunique expected to be float or int type")

        if null_frq < 0.0 or null_frq > 1.0:
            raise ValueError("null_frq expected to take values from 0 to 1")

        if max_shares < 0.0 or max_shares > 1.0:
            raise ValueError("max_shares expected to take values from 0 to 1")

        if nunique <= 1.0:
            raise ValueError("nunique expected to be greater than 1")

        self.null_frq = null_frq
        self.max_shares = max_shares
        self.nunique = nunique

    def fit(self, X, y=None):
        """
        Checks and sores names of the data columns that do not 
        meet the technical criteria.

        Args:
            X (pd.DataFrame) of shape (n_samples, n_features): 
                Data table with variables to check.

            y (None): 
                Ignored.

        Returns:
            object: 
                Fitted base filter.
        """

        X_copy = X.copy()
        self.n_features_in_ = X_copy.shape[1]

        self.excl_ = (X_copy.agg([lambda x: x.isna().mean(),
                                  lambda x: x.value_counts().max()/len(x),
                                  lambda x: x.nunique()])
                                  .T
                                  .set_axis(['null_frq', 'max_shares', 'nunique'], axis=1))
        
        self.excl_['null_frq_excl'] = self.excl_['null_frq'] > self.null_frq
        self.excl_['max_shares_excl'] = self.excl_['max_shares'] > self.max_shares
        self.excl_['nunique_excl'] = self.excl_['nunique'] < self.nunique

        self.excl_['all_excl'] = np.where(((self.excl_['null_frq_excl'] == True) |
                                           (self.excl_['max_shares_excl'] == True) |
                                           (self.excl_['nunique_excl'] == True)),1,0)
        
        self.cols_to_drop_ = list(self.excl_.index[self.excl_['all_excl'] == 1])
        self.cols_to_keep_ = [x for x in X_copy.columns.to_list() if x not in self.cols_to_drop_]
        self.feature_names_in_ = self.cols_to_keep_

        return self
    
    def transform(self, X, y=None):
        """_summary_

        Args:
            X (_type_): _description_
            y (_type_, optional): _description_. Defaults to None.
        """

        check_is_fitted(self)
        if self.n_features_in_ != X.shape[1]:
            raise ValueError("Wrong number of features")
        
        if len(self.cols_to_keep_) == 0:
            raise ValueError("No columns to keep, check threshold values")
        
        X_copy = X.copy()
        if len(self.cols_to_drop_) == 0:
            return X_copy
        else:
            return X_copy.loc[:, self.cols_to_keep_]


    def get_feature_names_out(self, input_features=None):
        if input_features is None:
            return getattr(self, "feature_names_in"), [f"x{i}" for i in range(self.n_features_in_)]
        else:
            if len(input_features) != self.n_features_in_:
                raise ValueError("input features not equal to feature_names_in")

            return self.feature_names_in_

from sklearn.metrics import mean_absolute_percentage_error
class GeneticFeatureSelector(BaseEstimator, TransformerMixin):

    def __init__(self,
                 estimator,
                 min_features: int = 1,
                 max_features: int = 10,
                 cv: int = 1,
                 fit_score_type: str = 'f1',
                 fit_error_weight: float = 1,
                 overfit_error_weight: float = 1,
                 varnum_error_weight: float = 1,
                 early_stopping_rounds: int = 10,
                 ga_settings: dict = None,
                 debug_mode: bool = False):
        
        self.max_features = max_features
        self.min_features = min_features
        self.debug_mode = debug_mode
        self.cv = cv
        self.fit_score_type = fit_score_type
        self.estimator = estimator
        self.fit_error_weight = fit_error_weight
        self.varnum_error_weight = varnum_error_weight
        self.overfit_error_weight = overfit_error_weight
        self.early_stopping_rounds = early_stopping_rounds

        self.ga_settings = {'num_generations': 100,
                            'num_parents_mating': 4,
                            'sol_per_pop': 20,
                            'init_range_low': 0,
                            'init_range_high': 2,
                            'save_best_solutions': True,
                            'mutation_by_replacement': True,
                            'parent_selection_type': 'sss',
                            'crossover_type': 'single_point',
                            'mutation_type': 'random',
                            'mutation_percent_genes': 15,
                            'stop_criteria': ['saturate_' + str(int(self.early_stopping_rounds))]}
        
        if ga_settings is not None:
            self.ga_settings.update(ga_settings)

        self.best_solution_ = None
        self.best_fittness_ = None
        self.solutions_all_ = []


    def fit(self, X, y=None, sample_weight=None):
        
        if isinstance(y, pd.DataFrame):
            y_copy = y.copy().reset_index(drop=True)
        else:
            y_copy = y.copy()

        if isinstance(X, pd.DataFrame):
            X_copy = X.copy().reset_index(drop=True)
        else:
            X_copy = X.copy()

        self.n_features_in_ = X_copy.shape[1]

        solutions_ = []
        splits = []

        prng = np.random.RandomState(1234567890)
        
        for rnd_seed in prng.randint(1,100, size=self.cv):
            if sample_weight is None:
                (X_train, X_test, 
                 y_train, y_test) = train_test_split(X_copy, y_copy, 
                                         random_state=rnd_seed, 
                                         test_size=0.25)
                
                if isinstance(X_train, pd.DataFrame):
                    X_train = X_train.to_numpy()
                if isinstance(X_test, pd.DataFrame):
                    X_test = X_test.to_numpy()

                splits.append((X_train, X_test, y_train, y_test))
            else:
                (X_train, X_test, 
                 y_train, y_test, 
                 w_train, w_test) = train_test_split(X_copy, y_copy, sample_weight, 
                                         random_state=rnd_seed, test_size=0.25)
                
                if isinstance(X_train, pd.DataFrame):
                    X_train = X_train.to_numpy()
                if isinstance(X_test, pd.DataFrame):
                    X_test = X_test.to_numpy()
                
                splits.append((X_train, X_test, 
                                y_train, y_test, 
                                w_train, w_test))

            # splits.append(split)

        def fitness_func(ga_instance, solution, solution_idx):

            var_num = np.sum(np.array(solution) == 1)
            if var_num < self.min_features:
                return -10000

            train_score = 0
            test_score = 0

            for index, split in enumerate(splits):
                if sample_weight is None:    
                    X_train, X_test, y_train, y_test = split
                else:
                    X_train, X_test, y_train, y_test, w_train, w_test = split

                model = clone(self.estimator)

                # if isinstance(X_train, pd.DataFrame):
                #     X_train = X_train.to_numpy()
                # if isinstance(X_test, pd.DataFrame):
                #     X_test = X_test.to_numpy()

                if sample_weight is None:
                    model = model.fit(X_train[:, np.array(solution) == 1], y_train)
                else:
                    model = model.fit(X_train[:, np.array(solution) == 1], y_train, 
                                      sample_weight = w_train)
        
                if ((self.fit_score_type == 'gini') or 
                    (self.fit_score_type == 'f1') or 
                    (self.fit_score_type == 'pr-auc')):
                    y_train_pred = model.predict_proba(X_train[:, np.array(solution) == 1])[:,1]
                    y_test_pred = model.predict_proba(X_test[:, np.array(solution) == 1])[:,1]
                else:
                    y_train_pred = model.predict(X_train[:, np.array(solution) == 1])
                    y_test_pred = model.predict(X_test[:, np.array(solution) == 1])

                if self.fit_score_type == 'f1':
                    precision, recall, _ = precision_recall_curve(y_train, y_train_pred)
                    f1_scores = 2 * recall * precision / (recall + precision)
                    if np.isnan(np.max(f1_scores)) or np.max(f1_scores) < 0:
                        pass
                    else:
                        train_score += np.max(f1_scores)

                    precision, recall, _ = precision_recall_curve(y_test, y_test_pred)
                    f1_scores = 2 * recall * precision / (recall + precision)
                    if np.isnan(np.max(f1_scores)) or np.max(f1_scores) < 0:
                        pass
                    else:
                        test_score += np.max(f1_scores)
                
                elif self.fit_score_type == 'pr-auc':
                    precision, recall, _ = precision_recall_curve(y_train, y_train_pred)
                    train_score += auc(recall, precision)
                    precision, recall, _ = precision_recall_curve(y_test, y_test_pred)
                    test_score += auc(recall, precision)
                elif self.fit_score_type == 'accuracy':
                    train_score += accuracy_score(y_train, y_train_pred)
                    test_score += accuracy_score(y_test, y_test_pred)
                elif self.fit_score_type == 'precision':
                    train_score += precision_score(y_train, y_train_pred)
                    test_score += precision_score(y_test, y_test_pred)
                elif self.fit_score_type == 'recall':
                    train_score += recall_score(y_train, y_train_pred)
                    test_score += recall_score(y_test, y_test_pred)
                elif self.fit_score_type == 'gini':
                    train_score += (2 * roc_auc_score(y_train, y_train_pred) - 1)
                    test_score += (2 * roc_auc_score(y_test, y_test_pred) - 1)
                elif self.fit_score_type == 'r2_score':
                    train_score += np.clip(r2_score(y_train, y_train_pred),0,1)
                    test_score += np.clip(r2_score(y_test, y_test_pred),0,1)
                elif self.fit_score_type == 'mape':
                    train_score += np.clip(1 - mean_absolute_percentage_error(y_train, y_train_pred),0 ,1)
                    test_score += np.clip(1 - mean_absolute_percentage_error(y_test, y_test_pred),0 ,1)
                elif self.fit_score_type == 'mae':
                    train_score += np.clip(1 - np.mean(np.abs(y_train - y_train_pred)),0 ,1)
                    test_score += np.clip(1 - np.mean(np.abs(y_test - y_test_pred)),0 ,1)

                else:
                    ValueError(" nieznany target")

            train_score = train_score / self.cv
            test_score = test_score / self.cv

            fit_error = train_score**self.fit_error_weight
            
            if train_score <= 0:
                overfit_error = 0
            else: 
                if ((test_score - train_score) / train_score) > 0:
                    overfit_error = (1 - ((test_score - train_score) / train_score))**self.overfit_error_weight
                else:
                    overfit_error = 1

            if var_num > self.max_features:
                varnum_error = (1 - ((var_num-self.max_features) / (len(solution)-self.max_features)))**self.varnum_error_weight
            else:
                varnum_error = 1

            penalty = (fit_error*overfit_error*varnum_error)**(1/3)

            if self.debug_mode:
                print((f"fit_error: {fit_error}, "
                       f"overfit_error: {overfit_error}, " 
                       f"varnum_error: {varnum_error}"))

            if hasattr(X_copy, 'columns'):
                solution_vars = set(X_copy.columns[np.array(solution)==1].to_list())
            else:
                solution_vars = set(np.where(solution)[0].tolist())

            if solution_vars not in solutions_:
                sol_summary = {'train_score': train_score,
                               'test_score': test_score,
                               'penalty': penalty,
                               'var_num': var_num,
                               'vars': list(solution_vars)}
                self.solutions_all_.append(sol_summary)
                solutions_.append(solution_vars)
            
            return penalty
        
        def on_gen(ga_instance):
            print("Generation: ", ga_instance.generations_completed)
            print("Fitness of the best solution: ", np.max(ga_instance.best_solutions_fitness))

        self.ga_settings['gene_type'] = X_copy.shape[1]*[int]
        self.ga_settings['num_genes'] = X_copy.shape[1]
        self.ga_settings['fitness_func'] = fitness_func
        self.ga_settings['gene_space'] = {'low': 0, 'high': 2}
        
        ga_instance = pygad.GA(**self.ga_settings, on_generation=on_gen)
        ga_instance.run()
        
        self.solutions_all_ = pd.DataFrame(self.solutions_all_)

        best_index = np.argmax(ga_instance.best_solutions_fitness)
        self.best_fittness_ = ga_instance.best_solutions_fitness[best_index]
        if hasattr(X_copy, 'columns'):
            self.best_solution_ = X_copy.columns[np.array(ga_instance.best_solutions[best_index]) == 1].to_list()
        else:
            self.best_solution_ = set(np.where(ga_instance.best_solutions[best_index])[0].tolist())
        
        self.cols_to_keep_ = self.best_solution_
        self.feature_names_in_ = self.best_solution_

        return self
    

    def best_solution(self):
        return self.best_solution_
    

    def transform(self, X, y=None):
        check_is_fitted(self)
        if self.n_features_in_ != X.shape[1]:
            raise ValueError("Wrong number of features")
        
        if len(self.cols_to_keep_) == 0:
            raise ValueError("No columns to keep, check treshold values")
        
        return X[self.cols_to_keep_].copy()
    

    def get_feature_names_out(self, input_features=None):
        if input_features is None:
            return getattr(self, "feature_names_in"), [f"x{i}" for i in range(self.n_features_in_)]
        else:
            if len(input_features) != self.n_features_in_:
                raise ValueError("input features not equal to feature_names_in")

            return self.feature_names_in_

class GiniFilter(BaseEstimator, TransformerMixin):

    def __init__(self, threshold=0.1):
        if (isinstance(threshold, (float, int)) is False):
            raise TypeError("threshold expected to be int or float type")
        if (threshold < 0) or (threshold > 1):
            raise ValueError("threshold expected to be in range from 0 to 100")
        
        self.threshold = threshold

    def fit(self, X, y=None):

        X_copy = X.copy()
        self.n_features_in_ = X_copy.shape[1]
        if (hasattr(X_copy, 'columns')):
            feature_names = X.columns.tolist()
        
        X_copy = X_copy.reset_index(drop=True)
        y = y.reset_index(drop=True)

        tab = pd.concat([X_copy, y], axis='columns')
        gini = get_gini_table(tab, feature_names, tab.columns[-1])

        self.gini_ = gini.copy()

        self.cols_to_keep_ = gini.index[gini['GINI'] > self.threshold].to_list()
        self.cols_to_drop_ = gini.index[gini['GINI'] <= self.threshold].to_list()

        self.feature_names_in_ = self.cols_to_keep_

        return self
    
    def transform(self, X, y=None):

        check_is_fitted(self)
        if self.n_features_in_ != X.shape[1]:
            raise ValueError("Wrong number of features")
        
        if len(self.cols_to_keep_) == 0:
            raise ValueError("No columns to keep, check threshold values")
        
        X_copy = X.copy()
        if len(self.cols_to_drop_) == 0:
            return X_copy.reset_index(drop=True)
        else:
            return X_copy.loc[:, self.cols_to_keep_]
        

    def get_feature_names_out(self, input_features=None):
        if input_features is None:
            return getattr(self, "feature_names_in"), [f"x{i}" for i in range(self.n_features_in_)]
        else:
            if len(input_features) != self.n_features_in_:
                raise ValueError("input features not equal to feature_names_in")

            return self.feature_names_in_      


def feature_selection_pipeline(cat_vars: List[str] = None,
                               num_vars: List[str] = None,
                               target_type: str = 'binary',
                               num_corr_threshold: float = 0.8,
                               cat_corr_threshold: float = 0.8,
                               num_null_frq: float = 0.95,
                               cat_null_frq: float = 0.95,
                               num_max_shares: float = 0.95,
                               cat_max_shares: float = 0.95,
                               num_nunique: int = 2,
                               cat_nunique: int = 2,
                               num_iv_threshold: float = 0.1,
                               cat_iv_threshold: float = 0.2,
                            #    num_gini_threshold: float = 0.1,
                            #    cat_gini_threshold: float = 0.2,
                               num_non_monotonic = False) -> Pipeline:
    
    cat_pipeline = make_pipeline(
        BaseFilter(null_frq=cat_null_frq, 
                   max_shares=cat_max_shares, 
                   nunique=cat_nunique),
        # OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=np.nan),
        BinningFilter(target_type=target_type,
                      variable_type='categorical',
                      iv_threshold=cat_iv_threshold),
        # GiniFilter(threshold=cat_gini_threshold),
        CorrelationFilter(target_type=target_type,
                          variable_type='binned',
                          threshold=cat_corr_threshold))
    
    num_pipeline = make_pipeline(
        BaseFilter(null_frq=num_null_frq, 
                   max_shares=num_max_shares, 
                   nunique=num_nunique),
        BinningFilter(target_type=target_type,
                      variable_type='numerical',
                      iv_threshold=num_iv_threshold, 
                      allow_nonmonotonic=num_non_monotonic),
        # GiniFilter(threshold=num_gini_threshold),
        CorrelationFilter(target_type=target_type,
                          variable_type='binned',
                          threshold=num_corr_threshold))

    if ((cat_vars is not None) and (num_vars is not None)):
        preprocessing = ColumnTransformer(
            transformers=[('cat', cat_pipeline, cat_vars),
                          ('num', num_pipeline, num_vars)],
                          remainder='drop')
    elif ((cat_vars is None) and (num_vars is not None)):
        preprocessing = ColumnTransformer(
            transformers=[('num', num_pipeline, num_vars)],
                          remainder='drop')
        
    elif ((cat_vars is not None) and (num_vars is None)):
        preprocessing = ColumnTransformer(
            transformers=[('cat', cat_pipeline, cat_vars)],
                          remainder='drop')
    else:
        raise ValueError("Provide column names with categorical or numerical variables")
    
    return Pipeline([('preprocessing',preprocessing),])


def pipeline_summary(pipe, verbose=True):

    HEADER = "\033[95m" 
    OKBLUE = "\033[94m" 
    OKCYAN = "\033[96m" 
    OKGREEN = "\033[92m" 
    WARNING = "\033[93m" 
    FAIL = "\033[91m" 
    ENDC = "\033[0m" 
    BOLD = "\033[1m" 
    UNDERLINE = "\033[4m" 

    cat_tabs = []
    num_tabs = []

    binning_summary = {}

    for transformer in pipe[0].transformers_:

        name, steps, _ = transformer

        for step in steps:
            if isinstance(step, BaseFilter):
                temp = (step.excl_
                        .copy()
                        .drop('all_excl', axis='columns')
                        .reset_index(names='variable'))
                if len(temp) != 0:
                    if name == 'cat':
                        temp.insert(loc=1, column='type', value='C')
                        cat_tabs.append(temp.copy()) 
                    elif name == 'num':
                        temp.insert(loc=1, column='type', value='N')
                        num_tabs.append(temp.copy())
                    else:
                        pass
            
            if isinstance(step, CorrelationFilter):
                temp = (pd.DataFrame({'variable': list(step.cols_to_drop_),
                                      'corr_excl': 1}))
                
                if len(temp) != 0:
                    if name == 'cat':
                        cat_tabs.append(temp.copy())
                    elif name == 'num':
                        num_tabs.append(temp.copy())
                    else:
                        pass
            
            # if isinstance(step, GiniFilter):
            #     gini_thr = step.threshold

            #     gini_values = step.gini_.reset_index()
            #     gini_values.columns = ['variable', 'gini']
            #     gini_values['gini_excl']  = gini_values['gini'] < gini_thr
            #     gini_values = gini_values[['variable','gini_excl', 'gini']]
            #     if len(temp) != 0:
            #         if name == 'cat':
            #             cat_tabs.append(gini_values.copy())
            #         elif name == 'num':
            #             num_tabs.append(gini_values.copy())
            #         else:
            #             pass


            if isinstance(step, BinningFilter):
                iv_thr = step.iv_threshold
                
                temp = []
                for index, col in enumerate(step.ob_.keys()):
                    iv = step.iv_[col]
                    binning_summary[col] = step.ob_[col].binning_table.build()
                    temp.append({'variable': col,
                                 'iv_excl': iv < iv_thr,
                                 'iv': np.round(iv,2),})

                if len(temp) != 0:
                    if name == 'cat':
                        cat_tabs.append(pd.DataFrame(temp))
                    elif name == 'num':
                        num_tabs.append(pd.DataFrame(temp))
                    else:
                        pass

    cat_tabs = reduce(lambda left, right: pd.merge(left, right,
                                                   on=['variable'],
                                                   how='left'), cat_tabs)
    
    num_tabs = reduce(lambda left, right: pd.merge(left, right,
                                                   on=['variable'],
                                                   how='left'), num_tabs)
    
    summary = pd.concat([cat_tabs, num_tabs], axis='index')
    summary = summary.sort_values(by='iv', ascending=False)
    
    if 'corr_excl' in summary.columns:
        summary.loc[summary['corr_excl'].isna(), 'corr_excl'] = 0
    else:
        summary['corr_excl'] = 0

    summary['corr_excl'] = np.where(summary['corr_excl'] == 1, True, False)
    

    summary.loc[summary['iv_excl'].isna(), 'iv_excl'] = False
    # summary.loc[summary['gini_excl'].isna(), 'gini_excl'] = False
    # summary.loc[summary['target_corr_excl'].isna(), 'target_corr_excl'] = False

    # excl = summary[['type', 'null_frq_excl', 'max_shares_excl',
    #                 'nunique_excl', 'iv_excl', 'gini_excl', 'corr_excl']].copy()
    
    excl = summary[['type', 'null_frq_excl', 'max_shares_excl',
                    'nunique_excl', 'iv_excl','corr_excl']].copy()
    

    excl['base'] = excl.apply(lambda x: 1 if ((x['null_frq_excl'] is True) or
                                              (x['max_shares_excl'] is True) or 
                                              (x['nunique_excl'] is True)) else 0, axis = 1)
    
    excl['bin'] = excl.apply(lambda x: 1 if (x['iv_excl'] is True) else 0, axis = 1)
    
    # excl['gini'] = excl['gini_excl'].astype(int)
    excl['cor'] = excl['corr_excl'].astype(int)

    excl = excl[['type', 'base', 'bin', 'cor']]

    excl = excl.groupby(by='type').agg(initial=('type', 'count'),
                                       base=('base','sum'),
                                       bin=('bin', 'sum'),
                                    #    gini=('gini', 'sum'),
                                       cor=('cor', 'sum'))
    
    excl['total'] = excl[['base', 'bin', 'cor']].sum(axis='columns')
    excl = excl.reset_index()

    if verbose:
        print("Exclusion summary:\n")
        s = (f"{'Type':<8} " +
             f"{'Initial':<10} " +
             f"{'BaseFilter':<10} " +
             f"{'BinningFilter':<14} " +

            #  f"{'GiniFilter':<14} " +

             f"{'CorrelationFilter':<18} " +
             f"{'Excluded':<8} " + 
             f"{'selected':<14}")
        print(s)

        for index, row in excl.iterrows():
            s = (f"{row['type']:<8} " +
                 f"{row['initial']:<10} " +
                 f"{row['base']:<10} " +
                 f"{row['bin']:<14} " +

                #  f"{row['gini']:<14} " +

                 f"{row['cor']:<18} " +
                 f"{row['total']:<8} " + 
                 f"{row['initial'] - row['total']:<14}")
            print(s)

        print("\n")

        print("Exclusion table:\n")
        print(f"{FAIL}" + "xxx" + f"{ENDC}" + " - excluded by BaseFilter")
        print(f"{WARNING}" + "xxx" + f"{ENDC}" + " - excluded by BinningFilter")
        # print(f"{OKCYAN}" + "xxx" + f"{ENDC}" + " - excluded by GiniFilter")
        print(f"{'xxx'}" + " - excluded by CorrelationFilter")
        print(colored("xxx", "yellow", "on_green")+ " - selected for the model" + "\n")

        s = (f"{HEADER}{'variable':<40} " +
            f"{'null_frq':<10} " +
            f"{'max_shares':<12} " +
            f"{'nunique':<10} " +
            f"{'null_frq_excl':<15} " +
            f"{'max_shares_excl':<15} " +
            f"{'nunique_excl':<15} " +
            f"{'corr_excl':<12} " +

            # f"{'gini_excl':<12} " +
            # f"{'gini':<10} " +

            f"{'iv_excl':<12} " +
            f"{'iv':<10} " +
            f"{'type'}{ENDC}")
        
        print(s)

        for index, row in summary.iterrows():
            s = (f"{row['variable']:<40} " +
                f"{np.round(row['null_frq'],3):<10} " +
                f"{np.round(row['max_shares'],3):<12} " +
                f"{np.round(row['nunique'],3):<10} " +
                f"{row['null_frq_excl']:<15} " +
                f"{row['max_shares_excl']:<15} " +
                f"{row['nunique_excl']:<15} " +
                f"{row['corr_excl']:<12} " +

                # f"{row['gini_excl']:<12} " +
                # f"{np.round(row['gini'],3):<10} " +

                f"{row['iv_excl']:<12} " +
                f"{row['iv']:<10} " +
                f"{row['type']}")
            
            if row['null_frq_excl'] or row['max_shares_excl'] or row['nunique_excl']:
                print(f"{FAIL}" + s + f"{ENDC}")
            elif row['iv_excl']:
                print(f"{WARNING}" + s + f"{ENDC}")
            # elif row['gini_excl']:
            #     print(f"{OKCYAN}" + s + f"{ENDC}")
            # elif (row['corr_excl'] is False) and (row['gini_excl'] is False):
            elif row['corr_excl'] is False:
                print(colored(s, "yellow", "on_green"))
            else:
                print(s)

    return summary, excl, binning_summary
        

if __name__ == "__main__":

    pass