import numpy as np
import pandas as pd


class observation_space:
    def __init__(self, n):
        self.shape = (n,)

class action_space():
    def __init__(self,n):
        self.n = n
    def seed(self, seed):
        pass
    def sample(self):
        return np.random.randint(0, self.n-1)

class FinEnv():

    def __init__(self, symbol, features, window, lags,
                 leverage=1, min_performance=0.85, 
                 start=0, end=None, mu=None, std=None):
        
        self.symbol = symbol
        self.features = features
        self.n_features = len(features)
        self.window = window
        self.lags = lags
        self.leverage = leverage
        self.min_performance = min_performance
        self.start = start
        self.end = end
        self.mu = mu
        self.std = std
        self.observation_space = observation_space(self.lags)
        self.action_space = action_space(2)
        self._get_data()
        self._prepare_data()

    def _get_data(self):
        self.raw = pd.read_csv(self.url, index_col=0, parse_dates=True).dropna()

    def _prepare_data(self):

        self.data = pd.DataFrame(self.raw[self.symbol])
        self.data = self.data.iloc[self.start:]

        self.data['r'] = np.log(self.data / self.data.shift(1))
        self.data.dropna(inplace=True)

        self.data['s'] = self.data[self.symbol].rolling(self.window).mean()
        self.data['m'] = self.data['r'].rolling(self.window).mean()
        self.data['v'] = self.data['r'].rolling(self.window).std()
        self.data.dropna(inplace=True)

        if self.mu is None:
            self.mu = self.data.mean()
            self.std = self.data.std()
        
        self.data_ = (self.data - self.mu) / self.std

        self.data_['d'] = np.where(self.data['r'] > 0, 1, 0)
        self.data_['d'] = self.data_['d'].astype(int)

        if self.end is not None:
            self.data = self.data.iloc[:self.end - self.start]
            self.data_ = self.data.iloc[:self.end - self.start]

    def _get_state(self):
        return self.data_[self.features].iloc[self.bar-self.lags:self.bar]
    
    def seed(self, seed):
        np.random.seed(seed)
    
    def reset(self):

        self.treward=0
        self.accuracy=0
        self.performance=0
        self.bar = self.lags
        state = self.data_[self.features].iloc[(self.bar-self.lags):self.bar]

        return state.values
    
    def step(self,action):
        correct = action == self.data_['d'].iloc[self.bar]
        ret = self.data['r'].iloc[self.bar] * self.leverage

        reward_1 = 1 if correct else 0
        reward_2 = abs(ret) if correct else -abs(ret)

        factor = 1 if correct else -1

        self.treward += reward_1
        self.accuracy = self.treward / (self.bar - self.lags)
        self.performance *= np.exp(reward_2)
        
        self.bar += 1

        if self.bar >= len(self.data):
            done = True
        elif reward_1 == 1:
            done =  False
        elif ((self.performance < self.min_performance) and (self.bar > self.lags + 5)):
            done = True
        else:
            done = False

        state = self._get_state()

        info = {}
        return state.values, reward_1 + reward_2 * 5, done, info
        
        




