import numpy as np
import pandas as pd
from typing import Tuple

from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LinearRegression
import seaborn as sns
import matplotlib.pyplot as plt
from src.classes.scoring_tools import custom_plot_style

def binary_binning(data: pd.DataFrame, target: str, 
                   variable:str, bins: int, 
                   lower_lim = 0, upper_lim = 1) -> Tuple[np.ndarray, pd.DataFrame]:
    
    binning_data = data.copy()
    out, edges = pd.cut(binning_data[binning_data[target]==1][variable],
                        bins, retbins=True, precision=8,
                        duplicates='drop', labels=range(bins))
    
    edges[0] = lower_lim
    edges[-1] = upper_lim

    binning_data['bins'] = pd.cut(binning_data[variable], bins=edges,
                                  labels=range(bins), precision=8, 
                                  include_lowest=True)
    
    binning_data = (binning_data
                    .groupby(by='bins')
                    .agg(events=(target,'sum'),
                         non_events=(target, lambda x: np.sum(x==0)),
                         all_events=(target,'count'),
                         event_rate=(target,'mean'),
                         mean_variable=(variable, 'mean'),)
                    .reset_index())
    # binning_data['variable'] = variable

    return edges, binning_data


class Calibrator():

    def __init__(self, estimator, bins=10):

        self.estimator = estimator
        self.bins = bins

    def fit_calibrator_(self, X, y):
        pass

    def predict_(self, X):
        pass

    def fit(self, X, y):

        raw_data = pd.DataFrame({
           'real': y,
           'model': self.estimator.predict_proba(X)[:,1]})
        

        _, self.calibration_table = binary_binning(raw_data, target='real', 
                                                   variable='model', bins=self.bins)

        self.calibrator = self.fit_calibrator_(self.calibration_table['mean_variable'],
                                               self.calibration_table['event_rate'])
        self.calibration_table['calibration'] = self.predict_(self.calibration_table['mean_variable'])
        self.calibration_table['shares'] = self.calibration_table['all_events'] / self.calibration_table['all_events'].sum()
        return self
    
    def predict_proba(self, X):
        pred = self.estimator.predict_proba(X)
        pred[:,1] = np.clip(self.predict_(pred[:,1]),0,1)
        pred[:,0] = 1 - pred[:,1]
        return pred
    
    def predict(self, X):
        pred = self.predict_(self.estimator.predict_proba(X)[:,1])
        return np.where(pred > 0.5, 1, 0)
    
    def summary(self):
        with plt.style.context(custom_plot_style):

            fig, ax = plt.subplots(ncols=2, nrows=1, figsize=(6,2.5), dpi=200)

            ax = ax.flatten()

            sns.lineplot(data= self.calibration_table, x='event_rate',
                         y='mean_variable', label = 'Raw model', ax=ax[0])

            sns.lineplot(data= self.calibration_table, x='event_rate',
                         y='calibration', label = 'Calibration', ax=ax[0])

            ax[0].axline((1,1), slope=1, alpha=0.5, color='gray', linestyle='--')
            ax[0].set_xlabel("Real probability")
            ax[0].set_ylabel("Predicted probability")
            ax[0].set_title("Calibration fit", fontsize=8)
            ax[0].set_xlim([0.0,1.0])
            ax[0].set_ylim([0.0,1.0])     
            ax[0].spines['top'].set_visible(True)
            ax[0].spines['right'].set_visible(True)
            ax[0].spines['left'].set_visible(True)
            ax[0].margins(0,0)

            ax[1].bar(self.calibration_table['bins'], 
                      self.calibration_table['shares'],
                      color='gray', alpha=0.35)
            ax[1].set_ylim([0.0,1.0])
            ax[1].set_xlim([-1, self.bins])
            ax[1].grid(False)
            
            ax_sec = ax[1].twinx()

            ax_sec.plot(self.calibration_table['bins'],
                        self.calibration_table['event_rate'],
                        'o', color="#1F77B4", markersize=2,label="Real probability")
            
            ax_sec.plot(self.calibration_table['bins'],
                        self.calibration_table['calibration'],
                        'o', color="#FF8113", markersize=2,label="Calibration probability")
            
            ax_sec.set_ylim([0.0, 1.0])
            ax_sec.margins(0.0, 0.0)
            ax_sec.set_ylabel("Probability")

            lines, labels = ax[1].get_legend_handles_labels()
            lines_sec, labels_sec = ax_sec.get_legend_handles_labels()

            ax[1].legend(lines + lines_sec, labels + labels_sec, loc='upper left')
            ax[1].margins(0.0,0.0)
            ax[1].set_title("Calibration curve", fontsize=8)
            ax[1].set_xlabel("Bin")
            ax[1].set_ylabel("Bin weight")
            ax[1].spines['top'].set_visible(True)
            ax[1].spines['right'].set_visible(True)
            ax[1].spines['left'].set_visible(True)

            fig.tight_layout(h_pad=0, w_pad=1)

            return fig, self.calibration_table.copy()


class IsotonicCalibrator(Calibrator):

    def fit_calibrator_(self, X, y):
        ir = IsotonicRegression(out_of_bounds="clip")
        return ir.fit(X,y)
    
    def predict_(self, X):
        return self.calibrator.predict(X)


class PolynomialCalibrator(Calibrator):

    def __init__(self, estimator, bins=10, poly_order=3):
        super().__init__(estimator, bins)
        self.poly_order = poly_order

    def fit_calibrator_(self, X, y):
        return np.poly1d(np.polyfit(X, y, self.poly_order))
    
    def predict_(self, X):
        return self.calibrator(X)
    

class SigmoidCalibrator(Calibrator):

    def fit_calibrtor_(self, X, y):
        lr = LinearRegression()
        return lr.fit(pd.DataFrame(X, columns=['model_proba']), np.log(y / (1 -y)))
    
    def predict_(self, X):
        X = pd.DataFrame(X, columns=['model_proba'])
        pred = self.calibrator.predict(X)
        return 1 / (1 + np.exp(-pred))
    

if __name__ == "__main__":

    pass