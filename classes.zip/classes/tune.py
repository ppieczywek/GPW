from sklearn.metrics import precision_recall_curve
from sklearn.metrics import auc
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import cross_validate

import numpy as np
import optuna
from xgboost import XGBClassifier
from xgboost import XGBRegressor


class base_tuner():

    def __init__(self, estimator_class, metric = "pr-auc"):
        self.estimator_class = estimator_class
        self.metric = metric

    def custom_scorer(self, estimator, X, y):
        y_pred = estimator.predict_proba(X)[:,1]
        precision, recall, _ = precision_recall_curve(y, y_pred)

        if self.metric == "pr-auc":
            return auc(recall, precision)
        elif self.metric == "roc-auc":
            return roc_auc_score(y, y_pred)
        elif self.metric == "f1":
            f1_scores = 2 * recall * precision / (recall + precision)
            if np.isnan(np.max(f1_scores)) or np.max(f1_scores) < 0:
                return 0
            else:
                return np.max(f1_scores)
        else:
            raise ValueError()
    
    def objective(self, trial, X, Y, estimator_class, param_func, fit_params):
        params = param_func(trial)
        model = estimator_class(**params)
        if (self.metric == "pr-auc") or (self.metric == "roc-auc") or (self.metric == "f1"):
            scores = cross_validate(model, X, Y, cv=3, fit_params=fit_params,
                                    scoring=self.custom_scorer)
        else:
            scores = cross_validate(model, X, Y, cv=3, fit_params=fit_params,
                                    scoring='neg_root_mean_squared_error')

        return np.mean(scores['test_score'])
    
    def get_params(self, trial):
        pass


    def tune(self, X, Y, n_trials=60, fit_params=None):
        
        self.study = optuna.create_study(direction='maximize')
        self.study.optimize(lambda trial: self.objective(trial, X, Y,
                                                         self.estimator_class,
                                                         self.get_params,
                                                         fit_params),
                                                         n_trials=n_trials)
        self.best_params = self.study.best_params
        self.tuned_estimator = self.estimator_class(**self.best_params)
        self.tuned_estimator = self.tuned_estimator.fit(X, Y)
        return self.tuned_estimator
    

class xgb_classifier_tuner(base_tuner):

    def __init__(self,
                 base_score,
                 max_delta_step = 1,
                 lambda_ = [0,10],
                 alpha = [0, 10],
                 n_estimators = [50, 1200],
                 max_depth = [2, 12],
                 learning_rate = [1e-3, 1.0],
                 subsample = [0.5, 1.0],
                 colsample_bytree = [0.5, 1.0],
                 metric = "pr-auc"):
        
        super().__init__(estimator_class=XGBClassifier,metric=metric)
        self.base_score = base_score
        self.objective_ = "binary:logistic"
        self.max_delta_step = max_delta_step
        self.lambda_ = lambda_
        self.alpha = alpha
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.learning_rate = learning_rate
        self.subsample = subsample
        self.colsample_bytree = colsample_bytree

    def get_params(self, trial):
        params = {
            'base_score': self.base_score,
            'objective': self.objective_,
            'max_delta_step': self.max_delta_step,
            'lambda': trial.suggest_float('lambda', self.lambda_[0], self.lambda_[1]),
            'alpha': trial.suggest_float('aplha', self.alpha[0], self.alpha[1]),
            'n_estimators': trial.suggest_int('n_estimators', self.n_estimators[0], self.n_estimators[1]),
            'max_depth': trial.suggest_int('max_depth', self.max_depth[0], self.max_depth[1]),
            'learning_rate': trial.suggest_float('learning_rate', self.learning_rate[0], self.learning_rate[1], log=True),
            'subsample': trial.suggest_float('subsample', self.subsample[0], self.subsample[1]),
            'colsample_bytree': trial.suggest_float('colsample_bytree', self.colsample_bytree[0], self.colsample_bytree[1]),
        }

        return params

class xgb_regressor_tuner(base_tuner):

    def __init__(self,
                 max_delta_step = 1,
                 lambda_ = [0,10],
                 alpha = [0, 10],
                 n_estimators = [50, 1200],
                 max_depth = [2, 12],
                 learning_rate = [1e-3, 1.0],
                 subsample = [0.5, 1.0],
                 colsample_bytree = [0.5, 1.0],
                 metric = "rmse"):
        
        super().__init__(estimator_class=XGBRegressor,metric=metric)
        self.max_delta_step = max_delta_step
        self.lambda_ = lambda_
        self.alpha = alpha
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.learning_rate = learning_rate
        self.subsample = subsample
        self.colsample_bytree = colsample_bytree

    def get_params(self, trial):
        params = {
            'max_delta_step': self.max_delta_step,
            'lambda': trial.suggest_float('lambda', self.lambda_[0], self.lambda_[1]),
            'alpha': trial.suggest_float('alpha', self.alpha[0], self.alpha[1]),
            'n_estimators': trial.suggest_int('n_estimators', self.n_estimators[0], self.n_estimators[1]),
            'max_depth': trial.suggest_int('max_depth', self.max_depth[0], self.max_depth[1]),
            'learning_rate': trial.suggest_float('learning_rate', self.learning_rate[0], self.learning_rate[1], log=True),
            'subsample': trial.suggest_float('subsample', self.subsample[0], self.subsample[1]),
            'colsample_bytree': trial.suggest_float('colsample_bytree', self.colsample_bytree[0], self.colsample_bytree[1]),
        }

        return params


if __name__ == "__main__":

    pass